"""
Provider registry.

Manages registration and instantiation of LLM providers.
"""
from __future__ import annotations

from typing import Type
from .base import LLMProvider


_providers: dict[str, Type[LLMProvider]] = {}


def register_provider(name: str, provider_class: Type[LLMProvider]):
    """Register a provider class."""
    _providers[name] = provider_class


def get_provider(name: str, **kwargs) -> LLMProvider:
    """
    Get a provider instance.
    
    Args:
        name: Provider name (anthropic, openai, openai_assistant, ollama, groq)
        **kwargs: Provider-specific args (api_key, model, etc.)
    
    Returns:
        Configured provider instance
    """
    if name not in _providers:
        raise ValueError(f"Unknown provider: {name}. Available: {list(_providers.keys())}")
    
    return _providers[name](**kwargs)


def list_providers() -> list[str]:
    """List registered provider names."""
    return list(_providers.keys())


# Register built-in providers
def _register_builtins():
    from .anthropic import AnthropicProvider
    from .openai import OpenAIProvider
    from .ollama import OllamaProvider
    from .groq import GroqProvider
    from .tinyroberta import TinyRobertaProvider
    
    register_provider("anthropic", AnthropicProvider)
    register_provider("openai", OpenAIProvider)
    register_provider("ollama", OllamaProvider)
    register_provider("groq", GroqProvider)
    register_provider("tinyroberta", TinyRobertaProvider)
    
    # OpenAI Assistant requires the openai SDK
    try:
        from ._openai_assistant import OpenAIAssistantProvider
        register_provider("openai_assistant", OpenAIAssistantProvider)
    except ImportError:
        pass  # SDK not installed


_register_builtins()
