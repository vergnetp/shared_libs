"""
Built-in auth stores that use the kernel's database connection.

These are automatically used when:
- auth_enabled=True (default)
- database is configured
- no custom user_store is provided
"""

import json
import uuid
from datetime import datetime
from typing import Optional, Dict, Any, List

from .router import UserStore


def _now() -> str:
    return datetime.utcnow().isoformat()


def _uuid() -> str:
    return str(uuid.uuid4())


class KernelUserStore(UserStore):
    """
    User store that uses the kernel's database connection.
    
    This is the default user store when database is configured.
    It implements the UserStore protocol expected by the auth router.
    """
    
    def __init__(self, get_db_connection):
        """
        Args:
            get_db_connection: The kernel's get_db_connection context manager
        """
        self._get_db = get_db_connection
    
    async def get_by_username(self, username: str) -> Optional[Dict[str, Any]]:
        """Get user by username (email)."""
        async with self._get_db() as db:
            results = await db.find_entities(
                "kernel_auth_users",
                where_clause="[email] = ?",
                params=(username,),
                limit=1,
                include_deleted=False,
                deserialize=True
            )
            if results:
                return self._entity_to_user(results[0])
            return None
    
    async def get_by_identity_hash(self, identity_hash: str) -> Optional[Dict[str, Any]]:
        """Get user by external identity hash (e.g. SHA256 of DO UUID).
        
        Used by external auth flows (DigitalOcean, etc.) where the user
        is identified by a stable hash rather than an email address.
        """
        async with self._get_db() as db:
            results = await db.find_entities(
                "kernel_auth_users",
                where_clause="[identity_hash] = ?",
                params=(identity_hash,),
                limit=1,
                include_deleted=False,
                deserialize=True
            )
            if results:
                return self._entity_to_user(results[0])
            return None
    
    async def get_by_id(self, user_id: str) -> Optional[Dict[str, Any]]:
        """Get user by ID."""
        async with self._get_db() as db:
            result = await db.get_entity(
                "kernel_auth_users",
                user_id,
                include_deleted=False,
                deserialize=True
            )
            if result:
                return self._entity_to_user(result)
            return None
    
    async def create(self, username: str, email: str, password_hash: str,
                     identity_hash: str = None) -> Dict[str, Any]:
        """Create new user.
        
        Args:
            username: Display name.
            email: Email address (can be empty for external-auth users).
            password_hash: Hashed password.
            identity_hash: Optional external identity hash for lookup.
        """
        async with self._get_db() as db:
            # Check for duplicate email (if provided)
            if email:
                existing = await db.find_entities(
                    "kernel_auth_users",
                    where_clause="[email] = ?",
                    params=(email,),
                    limit=1,
                    include_deleted=True
                )
                if existing:
                    raise ValueError(f"Email '{email}' already exists")
            
            # Check for duplicate identity_hash (if provided)
            if identity_hash:
                existing = await db.find_entities(
                    "kernel_auth_users",
                    where_clause="[identity_hash] = ?",
                    params=(identity_hash,),
                    limit=1,
                    include_deleted=True
                )
                if existing:
                    raise ValueError(f"Identity hash already exists")
            
            now = _now()
            user_id = _uuid()
            
            user_data = {
                "id": user_id,
                "email": email or None,
                "identity_hash": identity_hash,
                "password_hash": password_hash,
                "name": username,
                "role": "user",
                "is_active": 1,
                "created_at": now,
                "updated_at": now,
            }
            
            await db.save_entity("kernel_auth_users", user_data)
            
            return {
                "id": user_id,
                "username": username,
                "email": email or None,
                "identity_hash": identity_hash,
                "role": "user",
                "created_at": now,
            }
    
    async def update_password(self, user_id: str, password_hash: str) -> bool:
        """Update user's password hash."""
        async with self._get_db() as db:
            user = await db.get_entity("kernel_auth_users", user_id, include_deleted=False)
            if not user:
                return False
            
            user["password_hash"] = password_hash
            user["updated_at"] = _now()
            
            await db.save_entity("kernel_auth_users", user)
            return True
    
    async def update_email(self, user_id: str, email: str) -> bool:
        """Update user's email (e.g. when DO user provides real email later)."""
        async with self._get_db() as db:
            user = await db.get_entity("kernel_auth_users", user_id, include_deleted=False)
            if not user:
                return False
            
            user["email"] = email
            user["updated_at"] = _now()
            
            await db.save_entity("kernel_auth_users", user)
            return True
    
    def _entity_to_user(self, entity: Dict[str, Any]) -> Dict[str, Any]:
        """Convert database entity to user dict for auth router."""
        metadata = entity.get("metadata")
        if isinstance(metadata, str):
            try:
                metadata = json.loads(metadata)
            except (json.JSONDecodeError, TypeError):
                metadata = {}
        
        return {
            "id": entity.get("id"),
            "username": entity.get("email") or entity.get("name", ""),
            "email": entity.get("email"),
            "identity_hash": entity.get("identity_hash"),
            "password_hash": entity.get("password_hash"),
            "name": entity.get("name"),
            "role": entity.get("role", "user"),
            "metadata": metadata or {},
            "is_active": bool(entity.get("is_active", True)),
            "created_at": entity.get("created_at"),
            "updated_at": entity.get("updated_at"),
        }


def create_kernel_user_store(get_db_connection) -> KernelUserStore:
    """
    Factory function to create a KernelUserStore.
    
    Args:
        get_db_connection: The kernel's get_db_connection context manager
        
    Returns:
        KernelUserStore instance
    """
    return KernelUserStore(get_db_connection)
