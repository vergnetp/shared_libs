"""
Deployment Orchestrator - Background tasks for job_queue.

These tasks run in background workers and emit events via StreamContext.
FastAPI routes just enqueue jobs and return sse_response().

Architecture:
    ┌─────────────┐   enqueue    ┌─────────────┐   Redis    ┌─────────────┐
    │   FastAPI   │────────────>│  job_queue  │<─────────>│   Worker    │
    │   Route     │              │   (Redis)   │            │  (task)     │
    └──────┬──────┘              └─────────────┘            └──────┬──────┘
           │                                                       │
           │ sse_response()                              ctx.log() │
           │                                                       │
           v                                                       v
    ┌─────────────┐   subscribe  ┌─────────────┐   publish ┌─────────────┐
    │   Client    │<────────────│ Redis PubSub │<──────────│ StreamCtx   │
    │   (SSE)     │              └─────────────┘            └─────────────┘

Usage in route:
    from shared_libs.backend.streaming import StreamContext, sse_response
    from shared_libs.backend.job_queue import get_queue_manager
    
    @router.post("/deploy")
    async def deploy(req: DeployRequest, user: UserIdentity = Depends(...)):
        ctx = StreamContext.create(
            workspace_id=str(user.id),
            project=req.project,
            env=req.environment,
            service=req.name,
        )
        
        queue = get_queue_manager()
        queue.enqueue(
            entity={"stream_ctx": ctx.to_dict(), "config": build_config(req)},
            processor="deploy",
        )
        
        return await sse_response(ctx.channel_id)

Usage in worker startup:
    from infra.deploy.orchestrator import DEPLOY_TASKS
    
    for name, task in DEPLOY_TASKS.items():
        config.operations_registry[name] = task
"""

from __future__ import annotations
import asyncio
import time
from dataclasses import dataclass, field, asdict
from typing import Dict, Any, List, Optional, TYPE_CHECKING

from .service import DeploymentService, MultiDeployConfig, MultiDeployResult, DeploySource

if TYPE_CHECKING:
    from shared_libs.backend.streaming import StreamContext


# =============================================================================
# Deploy Config (serializable for job queue)
# =============================================================================

@dataclass
class DeployJobConfig:
    """
    Serializable deployment configuration for job queue.
    
    Flattened version of MultiDeployConfig for JSON serialization.
    """
    # Required
    name: str
    workspace_id: str
    do_token: str
    agent_key: str
    
    # Project context
    project: Optional[str] = None
    environment: str = "prod"
    
    # Source
    source_type: str = "image"
    image: Optional[str] = None
    git_url: Optional[str] = None
    git_branch: str = "main"
    git_token: Optional[str] = None
    git_folders: Optional[List[Dict[str, Any]]] = None
    dockerfile: Optional[str] = None
    code_tar_b64: Optional[str] = None
    image_tar_b64: Optional[str] = None
    exclude_patterns: Optional[List[str]] = None
    
    # Infrastructure
    server_ips: List[str] = field(default_factory=list)
    new_server_count: int = 0
    snapshot_id: Optional[str] = None
    region: str = "lon1"
    size: str = "s-1vcpu-1gb"
    
    # Container
    port: int = 8000
    container_port: Optional[int] = None
    host_port: Optional[int] = None
    env_vars: Dict[str, str] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)
    
    # Service mesh
    depends_on: List[str] = field(default_factory=list)
    setup_sidecar: bool = True
    is_stateful: bool = False
    
    # Domain
    setup_domain: bool = False
    cloudflare_token: Optional[str] = None
    base_domain: str = "digitalpixo.com"
    domain_aliases: List[str] = field(default_factory=list)
    
    # Meta
    deployment_id: Optional[str] = None
    comment: Optional[str] = None
    deployed_by: Optional[str] = None
    
    # Rollback
    skip_pull: bool = False
    is_rollback: bool = False
    rollback_from_id: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'DeployJobConfig':
        valid_fields = {f.name for f in cls.__dataclass_fields__.values()}
        return cls(**{k: v for k, v in data.items() if k in valid_fields})
    
    def to_multi_config(self) -> MultiDeployConfig:
        """Convert to MultiDeployConfig for DeploymentService."""
        import base64
        
        config = MultiDeployConfig(
            name=self.name,
            port=self.port,
            container_port=self.container_port,
            host_port=self.host_port,
            env_vars=self.env_vars,
            environment=self.environment,
            tags=self.tags,
            source_type=DeploySource.from_value(self.source_type),
            git_url=self.git_url,
            git_branch=self.git_branch,
            git_token=self.git_token,
            git_folders=self.git_folders,
            image=self.image,
            skip_pull=self.skip_pull,
            server_ips=self.server_ips,
            new_server_count=self.new_server_count,
            snapshot_id=self.snapshot_id,
            region=self.region,
            size=self.size,
            dockerfile=self.dockerfile,
            project=self.project,
            workspace_id=self.workspace_id,
            deployment_id=self.deployment_id,
            depends_on=self.depends_on,
            setup_sidecar=self.setup_sidecar,
            is_stateful=self.is_stateful,
            setup_domain=self.setup_domain,
            cloudflare_token=self.cloudflare_token,
            base_domain=self.base_domain,
            domain_aliases=self.domain_aliases,
        )
        
        if self.code_tar_b64:
            config.code_tar = base64.b64decode(self.code_tar_b64)
        if self.image_tar_b64:
            config.image_tar = base64.b64decode(self.image_tar_b64)
        
        return config


# =============================================================================
# Background Tasks
# =============================================================================

def deploy_task(entity: Dict[str, Any]) -> Dict[str, Any]:
    """
    Deploy task for job_queue workers.
    
    Emits events via StreamContext → Redis Pub/Sub → SSE.
    """
    from shared_libs.backend.streaming import StreamContext
    
    start_time = time.time()
    
    ctx = StreamContext.from_dict(entity.get("stream_ctx", {}))
    config = DeployJobConfig.from_dict(entity.get("config", {}))
    
    ctx.log(f"🚀 Starting deployment: {config.name}")
    ctx.log(f"📦 Source: {config.source_type}")
    ctx.log(f"🌍 Environment: {config.environment}")
    if config.server_ips:
        ctx.log(f"🖥️ Servers: {', '.join(config.server_ips)}")
    
    try:
        result = _run_async(_deploy_async(ctx, config))
        duration = time.time() - start_time
        
        if result.success:
            ctx.log(f"✅ Deployment complete in {duration:.1f}s")
            ctx.complete(
                success=True,
                deployment_id=config.deployment_id,
                duration_seconds=duration,
                servers=[s.to_dict() for s in result.servers] if result.servers else [],
                container_name=result.container_name,
                internal_port=result.internal_port,
            )
        else:
            ctx.log(f"❌ Deployment failed: {result.error}")
            ctx.complete(
                success=False,
                error=result.error,
                deployment_id=config.deployment_id,
                duration_seconds=duration,
            )
        
        return {"success": result.success, "error": result.error}
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        duration = time.time() - start_time
        error_msg = str(e)
        ctx.log(f"❌ Deployment error: {error_msg}")
        ctx.complete(success=False, error=error_msg, duration_seconds=duration)
        return {"success": False, "error": error_msg}


def rollback_task(entity: Dict[str, Any]) -> Dict[str, Any]:
    """Rollback task - deploys a previous image version."""
    from shared_libs.backend.streaming import StreamContext
    
    start_time = time.time()
    
    ctx = StreamContext.from_dict(entity.get("stream_ctx", {}))
    config = DeployJobConfig.from_dict(entity.get("config", {}))
    
    config.skip_pull = True
    config.is_rollback = True
    
    ctx.log(f"🔄 Starting rollback: {config.name}")
    ctx.log(f"📌 Target image: {config.image}")
    
    try:
        result = _run_async(_deploy_async(ctx, config))
        duration = time.time() - start_time
        
        if result.success:
            ctx.log(f"✅ Rollback complete in {duration:.1f}s")
            ctx.complete(
                success=True,
                deployment_id=config.deployment_id,
                duration_seconds=duration,
                rolled_back_to=config.image,
            )
        else:
            ctx.complete(
                success=False,
                error=result.error,
                deployment_id=config.deployment_id,
                duration_seconds=duration,
            )
        
        return {"success": result.success, "error": result.error}
        
    except Exception as e:
        duration = time.time() - start_time
        ctx.complete(success=False, error=str(e), duration_seconds=duration)
        return {"success": False, "error": str(e)}


def stateful_deploy_task(entity: Dict[str, Any]) -> Dict[str, Any]:
    """Deploy stateful service (postgres, redis, etc)."""
    from shared_libs.backend.streaming import StreamContext
    
    start_time = time.time()
    
    ctx = StreamContext.from_dict(entity.get("stream_ctx", {}))
    config = DeployJobConfig.from_dict(entity.get("config", {}))
    
    config.is_stateful = True
    config.skip_pull = True
    
    ctx.log(f"🗄️ Deploying stateful service: {config.name}")
    ctx.log(f"📦 Image: {config.image}")
    
    try:
        result = _run_async(_deploy_async(ctx, config))
        duration = time.time() - start_time
        
        if result.success:
            ctx.log(f"✅ Stateful service ready in {duration:.1f}s")
            ctx.complete(
                success=True,
                deployment_id=config.deployment_id,
                duration_seconds=duration,
                service_type=config.name,
            )
        else:
            ctx.complete(success=False, error=result.error, duration_seconds=duration)
        
        return {"success": result.success, "error": result.error}
        
    except Exception as e:
        duration = time.time() - start_time
        ctx.complete(success=False, error=str(e), duration_seconds=duration)
        return {"success": False, "error": str(e)}


# =============================================================================
# Async Deployment
# =============================================================================

async def _deploy_async(ctx, config: DeployJobConfig) -> MultiDeployResult:
    """Run deployment using DeploymentService."""
    
    def log_callback(msg: str):
        ctx.log(msg)
    
    service = DeploymentService(
        do_token=config.do_token,
        agent_key=config.agent_key,
        log=log_callback,
    )
    
    return await service.deploy(config.to_multi_config())


def _run_async(coro):
    """Run async code in sync context (for job_queue workers)."""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()


# =============================================================================
# Task Registry
# =============================================================================

DEPLOY_TASKS = {
    "deploy": deploy_task,
    "rollback": rollback_task,
    "stateful_deploy": stateful_deploy_task,
}
