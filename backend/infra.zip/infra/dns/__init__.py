"""
DNS module - DNS cleanup utilities.

Usage (Sync):
    from infra.dns import DnsCleanupService
    result = DnsCleanupService(do_token, cf_token).cleanup_orphaned(zone_name)

Usage (Async):
    from infra.dns import AsyncDnsCleanupService
    result = await AsyncDnsCleanupService(do_token, cf_token).cleanup_orphaned(zone_name)
"""

from .service import DnsCleanupService, AsyncDnsCleanupService, DnsCleanupResult

__all__ = [
    "DnsCleanupService",
    "AsyncDnsCleanupService",
    "DnsCleanupResult",
]
