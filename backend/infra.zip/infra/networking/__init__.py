"""Networking - Nginx, SSL, routing, ports."""

from .nginx import (
    NginxConfigGenerator,
    ServerBlock,
    Location,
    Upstream,
    Backend,
    LoadBalanceMethod,
)
from .nginx_manager import (
    NginxManager,
    StreamConfig,
    StreamBackend,
    BackendMode,
    get_internal_port,
    get_host_port,
)
from .ports import DeploymentPortResolver
from .ssl import (
    SSLManager,
    Certificate,
)
from .service import NginxService, NginxResult

__all__ = [
    # Nginx config generation
    "NginxConfigGenerator",
    "ServerBlock",
    "Location",
    "Upstream",
    "Backend",
    "LoadBalanceMethod",
    # Nginx management
    "NginxManager",
    "StreamConfig",
    "StreamBackend",
    "BackendMode",
    # Nginx service (high-level)
    "NginxService",
    "NginxResult",
    # Port resolution
    "DeploymentPortResolver",
    "get_internal_port",
    "get_host_port",
    # SSL
    "SSLManager",
    "Certificate",
]
