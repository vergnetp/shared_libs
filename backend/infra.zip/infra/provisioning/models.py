"""
Provisioning models.
"""

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any


@dataclass
class ProvisionRequest:
    """Request to provision a new server."""
    region: str
    size: str = "s-1vcpu-1gb"
    snapshot_id: Optional[str] = None
    name: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    ssh_keys: List[str] = field(default_factory=list)
    vpc_uuid: Optional[str] = None
    project: Optional[str] = None
    environment: str = "prod"


@dataclass
class ProvisionResult:
    """Result of server provisioning."""
    success: bool
    server: Optional[Dict[str, Any]] = None
    vpc_uuid: Optional[str] = None
    error: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        result = {"success": self.success}
        if self.server:
            result["server"] = self.server
        if self.vpc_uuid:
            result["vpc_uuid"] = self.vpc_uuid
        if self.error:
            result["error"] = self.error
        return result
