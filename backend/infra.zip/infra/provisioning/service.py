"""
Provisioning Service - Server provisioning logic.

Usage (Sync - CLI/scripts):
    from infra.provisioning import ProvisioningService
    
    service = ProvisioningService(do_token, user_id)
    result = service.provision_server(region="lon1", size="s-1vcpu-1gb", snapshot_id="123")

Usage (Async - FastAPI):
    from infra.provisioning import AsyncProvisioningService
    
    service = AsyncProvisioningService(do_token, user_id)
    result = await service.provision_server(region="lon1", ...)
"""

from __future__ import annotations
from typing import List, Optional, Dict, Any

from .models import ProvisionRequest, ProvisionResult


class _BaseProvisioningService:
    """Base class with shared provisioning logic."""
    
    MANAGED_TAG = "deployed-via-api"
    
    def __init__(self, do_token: str, user_id: str):
        self.do_token = do_token
        self.user_id = user_id
        
        # Generate agent API key
        from ..cloud import generate_node_agent_key
        self.api_key = generate_node_agent_key(do_token, user_id)
    
    def _validate_tags(self, tags: List[str]) -> List[str]:
        """Ensure managed tag is present."""
        result = list(tags) if tags else []
        if self.MANAGED_TAG not in result:
            result.append(self.MANAGED_TAG)
        return result
    
    def _validate_snapshot_in_region(
        self,
        snapshot_id: str,
        region: str,
        snapshots: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """Validate snapshot exists and is in target region."""
        snapshot = None
        for s in snapshots:
            if str(s.get("id")) == str(snapshot_id):
                snapshot = s
                break
        
        if not snapshot:
            raise ValueError(f"Snapshot '{snapshot_id}' not found")
        
        available_regions = snapshot.get("regions", [])
        if region not in available_regions:
            raise ValueError(
                f"Snapshot '{snapshot.get('name')}' not available in region '{region}'. "
                f"Available: {', '.join(available_regions)}"
            )
        
        return snapshot


class ProvisioningService(_BaseProvisioningService):
    """Synchronous provisioning service for CLI and scripts."""
    
    def provision_server(
        self,
        region: str,
        size: str = "s-1vcpu-1gb",
        snapshot_id: Optional[str] = None,
        name: Optional[str] = None,
        tags: Optional[List[str]] = None,
        ssh_keys: Optional[List[str]] = None,
        vpc_uuid: Optional[str] = None,
        project: Optional[str] = None,
        environment: str = "prod",
    ) -> ProvisionResult:
        """Provision a new server (sync)."""
        from ..cloud import DOClient, SnapshotService
        from ..utils import generate_friendly_name
        
        client = DOClient(self.do_token)
        
        try:
            server_name = name.strip() if name else generate_friendly_name()
            final_tags = self._validate_tags(tags)
            final_ssh_keys = list(ssh_keys) if ssh_keys else []
            
            # Validate snapshot if provided
            if snapshot_id:
                snapshot_service = SnapshotService(self.do_token)
                snapshots = snapshot_service.list_snapshots()
                self._validate_snapshot_in_region(snapshot_id, region, snapshots)
                image = snapshot_id
            else:
                image = "ubuntu-24-04-x64"
            
            droplet = client.create_droplet(
                name=server_name,
                region=region,
                size=size,
                image=image,
                ssh_keys=final_ssh_keys,
                tags=final_tags,
                vpc_uuid=vpc_uuid,
                project=project,
                environment=environment,
                node_agent_api_key=self.api_key,
                wait=True,
            )
            
            return ProvisionResult(
                success=True,
                server=droplet.to_dict(),
                vpc_uuid=droplet.vpc_uuid,
            )
            
        except ValueError as e:
            return ProvisionResult(success=False, error=str(e))
        except Exception as e:
            error_msg = str(e)
            if "not available in the selected region" in error_msg:
                return ProvisionResult(
                    success=False,
                    error=f"Image not available in region '{region}'. Try different region."
                )
            return ProvisionResult(success=False, error=error_msg)
    
    def delete_server(self, server_id: int) -> ProvisionResult:
        """Delete a server (sync)."""
        from ..cloud import DOClient
        
        client = DOClient(self.do_token)
        try:
            result = client.delete_droplet(server_id)
            if result.success:
                return ProvisionResult(success=True)
            return ProvisionResult(success=False, error=result.error)
        except Exception as e:
            return ProvisionResult(success=False, error=str(e))
    
    def list_servers(self) -> List[Dict[str, Any]]:
        """List all managed servers (sync)."""
        from ..cloud import DOClient
        
        client = DOClient(self.do_token)
        droplets = client.list_droplets()
        return [d.to_dict() for d in droplets]


class AsyncProvisioningService(_BaseProvisioningService):
    """Asynchronous provisioning service for FastAPI."""
    
    async def provision_server(
        self,
        region: str,
        size: str = "s-1vcpu-1gb",
        snapshot_id: Optional[str] = None,
        name: Optional[str] = None,
        tags: Optional[List[str]] = None,
        ssh_keys: Optional[List[str]] = None,
        vpc_uuid: Optional[str] = None,
        project: Optional[str] = None,
        environment: str = "prod",
    ) -> ProvisionResult:
        """Provision a new server (async)."""
        from ..cloud import AsyncDOClient, AsyncSnapshotService
        from ..utils import generate_friendly_name
        
        client = AsyncDOClient(self.do_token)
        
        try:
            server_name = name.strip() if name else generate_friendly_name()
            final_tags = self._validate_tags(tags)
            final_ssh_keys = list(ssh_keys) if ssh_keys else []
            
            # Validate snapshot if provided
            if snapshot_id:
                snapshot_service = AsyncSnapshotService(self.do_token)
                try:
                    snapshots = await snapshot_service.list_snapshots()
                finally:
                    await snapshot_service.close()
                self._validate_snapshot_in_region(snapshot_id, region, snapshots)
                image = snapshot_id
            else:
                image = "ubuntu-24-04-x64"
            
            droplet = await client.create_droplet(
                name=server_name,
                region=region,
                size=size,
                image=image,
                ssh_keys=final_ssh_keys,
                tags=final_tags,
                vpc_uuid=vpc_uuid,
                project=project,
                environment=environment,
                node_agent_api_key=self.api_key,
                wait=True,
            )
            
            return ProvisionResult(
                success=True,
                server=droplet.to_dict(),
                vpc_uuid=droplet.vpc_uuid,
            )
            
        except ValueError as e:
            return ProvisionResult(success=False, error=str(e))
        except Exception as e:
            error_msg = str(e)
            if "not available in the selected region" in error_msg:
                return ProvisionResult(
                    success=False,
                    error=f"Image not available in region '{region}'. Try different region."
                )
            return ProvisionResult(success=False, error=error_msg)
        finally:
            await client.close()
    
    async def delete_server(self, server_id: int) -> ProvisionResult:
        """Delete a server (async)."""
        from ..cloud import AsyncDOClient
        
        client = AsyncDOClient(self.do_token)
        try:
            result = await client.delete_droplet(server_id)
            if result.success:
                return ProvisionResult(success=True)
            return ProvisionResult(success=False, error=result.error)
        except Exception as e:
            return ProvisionResult(success=False, error=str(e))
        finally:
            await client.close()
    
    async def list_servers(self) -> List[Dict[str, Any]]:
        """List all managed servers (async)."""
        from ..cloud import AsyncDOClient
        
        client = AsyncDOClient(self.do_token)
        try:
            droplets = await client.list_droplets()
            return [d.to_dict() for d in droplets]
        finally:
            await client.close()
