import json, os
from ..errors import Error

class MySqlDataBaseConfigItem:
    alias: str
    database: str
    host: str
    user: str
    password: str


class MySqlDataBaseConfig:
    prod: MySqlDataBaseConfigItem
    dev: MySqlDataBaseConfigItem


class SqliteDataBaseConfigItem:
    alias: str
    path: str

class SqliteDataBaseConfig:
    prod: SqliteDataBaseConfigItem
    dev: SqliteDataBaseConfigItem

def get_config(alias):
    try:
        config_file = os.path.abspath(__file__).replace('.py', '.json')
        if not os.path.exists(config_file):
            raise Error(None, "{0} does not exist".format(config_file), 'Please create it with at least this content: {"databases":[{"alias":"default","type":"sqlite","config":{"{env}":{"path":"repo|server|resources|files|databases|{env}|{name}.db"}}}]}')                                            
        with open(os.path.abspath(__file__).replace('.py', '.json')) as f:
            dico = json.load(f)        
            for db in dico["databases"]:
                if db["alias"] == alias:
                    for key in list(db['config']): 
                        if key == '{env}':
                            value = json.dumps(db['config'][key])                 
                            db['config']['dev'] = json.loads(value.replace('{env}', 'dev').replace('{name}', alias))
                            db['config']['uat'] = json.loads(value.replace('{env}', 'uat').replace('{name}', alias))
                            db['config']['prod'] = json.loads(value.replace('{env}', 'prod').replace('{name}', alias))
                            db['config']['test'] = json.loads(value.replace('{env}', 'test').replace('{name}', alias))
                    return db
    except Exception as e:
        raise Error(e, "Somehow {0} could not be parsed into a database config".format(config_file), 'Please check that it each database has an alias (str), type (sqlite or mysql), config (dictionary of the 4 environements). Example: {"databases":[{"alias":"default","type":"sqlite","config":{"{env}":{"path":"repo|server|resources|files|databases|{env}|{name}.db"}}}]}')
