import json
from . import sqlite
from . import mysql
from . import interface
from . import config
from .. import utils
from ..errors import Error, TrackError

@utils.profiled_function()
def get_database(alias: str, env='prod', background=False):
    """Returns a database object for this alias, as configured in config.json
       If not configured, returns a SqliteDataBase pointing to app|server|resources|database|{env}|{alias}.db 

    Args:
        alias (str): the alias for the database, as defined in config.json
        env (str, optional): 'prod' or 'uat' or 'dev' or custom. Defaults to 'prod'.
        background (bool, optional): wether the operation is expected to be a background task (like saving info about requests) or more important things.

    Returns:
        interface.Database: A database object. You can call execute_sqls on it
    """    
    try:
        db = config.get_config(alias)
        if db is None:
            db = config.get_config('Default')
            str = json.dumps(db).replace('{name}', alias)
            db = json.loads(str)
        type = db["type"]
        db_config = db["config"]
        if type is None:
            raise Exception('Cannot get the database {0} as the type is not defined in config.json'.format(alias))
        if db_config is None:       
            raise Exception('Cannot get the database {0} as the config is not defined in config.json'.format(alias))
        if type == 'sqlite':
            return sqlite.SqliteDataBase(db, env)
        if type == 'mysql':
            return mysql.MySqlDataBase(db, env, background)
        raise Exception('Cannot get the database {0} as the type defined in config.json, {1}, is not part of supported databases ("sqlite" etc.)'.format(alias, type))
    except Exception as e:
        raise Error(e, 'Problem creating a database object for alias  "{0}" and env "{1}"'.format(alias, env), action="Check inner error")