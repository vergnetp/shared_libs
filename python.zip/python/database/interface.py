# This is the the base class exposing all the methods that any DataBase class will fulfill

import uuid
from dataclasses import dataclass
from typing import List, Dict, Any, Tuple, Optional
from .. import log as logger
from ..errors import TrackError
from .. import utils

@dataclass
class Entity:
    id: str
    created: int

class DbSpecs:
    prod: Any

class DbConfig:
    alias: str
    type: str
    config: DbSpecs

class Database:
    def __init__(self, config: DbConfig, env: str = 'prod'):
        """
        Initialize the Database instance.

        Args:
            config (DbConfig): Database configuration object (or a dictionary)
            env (str, optional): The environment for the connection. Defaults to 'prod'.
        """     
        self.__env = env
        if not isinstance(config, dict):
            _config = config.__dict__
        else:
            _config = config
        self.__alias = _config.get('alias', 'NoAliasProvided')
        self.__type = _config.get('type', 'mysql')   

    def env(self) -> str:
        """
        Returns the environment
        """        
        return self.__env        
        
    def alias(self) -> str:
        """
        Returns the alias
        """
        try:
            return self.__alias
        except:
            raise NotImplementedError("Subclasses must implement this method.")
    
    def type(self) -> str:
        """
        Returns the type of database ('sqlite', 'mysql'...).
        """
        try:
            return self.__type
        except:
            raise NotImplementedError("Subclasses must implement this method.")

    def placeholder(self) -> str:
        """
        Returns the SQL placeholder for the given database.
        """        
        raise NotImplementedError("Subclasses must implement this method.")

    def begin_transaction(self) -> None:
        """
        Begin the transaction.
        """
        raise NotImplementedError("Subclasses must implement this method.")
    
    def close(self) -> None:
        """
        Close and release any resources (cursor, connection...).
        """
        raise NotImplementedError("Subclasses must implement this method.")
      
    def commit_transaction(self) -> None:
        """
        Commit the transaction.
        """
        raise NotImplementedError("Subclasses must implement this method.")

    def rollback_transaction(self) -> None:
        """
        Rollback the transaction.
        """
        raise NotImplementedError("Subclasses must implement this method.")

    def clear_all(self) -> None:
        """
        Drop and recreate the entire database.
        """
        raise NotImplementedError("Subclasses must implement this method.")
    
    def execute_sql(self, sql: str = '', parameters: Tuple[Any, ...] = (), auto_commit: bool=False, max_retries: int = 2) -> List[Any]:
        """
        Execute a single SQL query.

        Args:
            sql (str): SQL query to execute.
            parameters (Tuple[Any, ...]): Parameters for the SQL query.
            auto_commit (bool, optional): Whether to auto commit the transaction. Defaults to False.
            max_retries (int, optional): Number of retries in case of failure. Defaults to 2.

        Raises:
            Exception: Any exception that occurs during execution.

        Returns:
            List[Any]: List of results for the SQL query.
        """
        raise NotImplementedError("Subclasses must implement this method.")
    
    def _ensure_tables_exist(self, entity_name: str) -> None:
        try:
            # Create the 2 tables if needed:
            self.execute_sql('create table if not exists {0}_meta (name varchar(255) {1}, type varchar(255))'.format(entity_name, 'PRIMARY KEY' if self.type() == 'sqlite' else ',PRIMARY KEY (name)'))
            create_sql = "create table if not exists {0} (id VARCHAR(255) {1})".format(entity_name, 'PRIMARY KEY' if self.type() == 'sqlite' else ',PRIMARY KEY (id)')
            self.execute_sql(create_sql)
            self.commit_transaction()
        except Exception as e:
            self.rollback_transaction()
            raise TrackError(e)

    def _primary_key_clause(self) -> str:
        try:
            return 'PRIMARY KEY' if self.type() == 'sqlite' else ', PRIMARY KEY (id)'
        except Exception as e:
            raise TrackError(e)
        
    def save_entity(self, entity_name: str, entity: Entity) -> None:
        """
        Insert or replace an entity.

        Args:
            entity_name (str): The name of the entity to save.
            entity (Entity): The entity to save.
        """      
        try:
            self.begin_transaction()
            pl = self.placeholder()
            or_replace = 'OR REPLACE' if self.type() == 'sqlite' else ''
            on_duplicate_meta = 'ON DUPLICATE KEY UPDATE name=COALESCE(VALUES(name),name), type=COALESCE(VALUES(type),type)' if self.type() != 'sqlite' else ''
            on_duplicate = 'ON DUPLICATE KEY UPDATE ' if self.type() != 'sqlite' else ''
            
            self._ensure_tables_exist(entity_name)

            # Ensure we work on a dictionary:
            dico = entity.__dict__ if not isinstance(entity, dict) else entity
            dico = dict(sorted(dico.items()))

            # Add useful data:
            dico.setdefault('id', str(uuid.uuid4()))
            dico.setdefault('created', utils.get_now())
            dico['updated'] = utils.get_now()
            day, month, year = utils.get_current_date()
            dico.update({'Updated_day': day, 'Updated_month': month, 'Updated_year': year})

            keys = list(dico.keys())
            values = [str(dico[key]) for key in keys]
            place_holders = [pl] * len(keys)
            duplicates = [f'{key}=COALESCE(VALUES({key}),{key})' for key in [key for key in keys if key != 'created'] if on_duplicate]

            for key in keys:
                typ = str(type(dico[key]))
                ret = self.execute_sql(f"SELECT type FROM {entity_name}_meta WHERE name={pl}", (key,))
                if len(ret) == 0:
                    logger.info(f'Adding new column to {entity_name}: {key}')
                    self.execute_sql(f"INSERT {or_replace} INTO {entity_name}_meta VALUES ({pl},{pl}) {on_duplicate_meta}", (key, typ))
                    if key != 'id':
                        self.execute_sql(f"ALTER TABLE {entity_name} ADD {key} TEXT")
                else:
                    if dico[key] is not None and ret[0][0] == "<class 'NoneType'>":
                        self.execute_sql(f"INSERT {or_replace} INTO {entity_name}_meta VALUES ({pl},{pl}) {on_duplicate_meta}", (key, typ))

            insert_sql = f"INSERT {or_replace} INTO {entity_name} ({','.join(keys)}) VALUES ({','.join(place_holders)}) {on_duplicate} {', '.join(duplicates)}"
            self.execute_sql(insert_sql, tuple(values))
            self.commit_transaction()

        except Exception as e:
            self.rollback_transaction()
            raise TrackError(e)

    def _db_values_to_entity(self, entity_name: str, values: List[str], keys: Optional[List[str]] = None, types: Optional[List[str]] = None, cast: bool = False) -> Dict[str, Any]:
        """
        Converts a list of database values into a dictionary representation of an entity.

        This method maps raw values retrieved from the database to their corresponding keys and types,
        and returns the data as a dictionary. It optionally casts the values to their original types
        based on the metadata retrieved from the database.

        Args:
            entity_name (str): The name of the entity for which the values are being converted.
            values (List[str]): A list of values retrieved from the database for the entity.
            keys (Optional[List[str]], optional): A list of keys (column names) corresponding to the values.
                If not provided, it will be fetched from the database. Defaults to None.
            types (Optional[List[str]], optional): A list of data types corresponding to the values.
                If not provided, it will be fetched from the database. Defaults to None.
            cast (bool, optional): Whether to cast the values to their original types based on the metadata.
                Defaults to False. If True, the method uses the `utils.safe_deserialize` function to convert
                values to their original types.

        Returns:
            Dict[str, Any]: A dictionary where the keys are column names and the values are the corresponding
            data from the database. The values are cast to their original types if `cast` is True.

        Raises:
            TrackError: If there is an error while converting values or retrieving metadata from the database.
        """
        try:
            if keys is None:
                keys = [row[0] for row in self.execute_sql(f"SELECT name FROM {entity_name}_meta")]
            if types is None:
                types = [row[0] for row in self.execute_sql(f"SELECT type FROM {entity_name}_meta")]

            return {
                key: utils.safe_deserialize(value, target_type) if cast else value
                for key, value, target_type in zip(keys, values, types)
            }
        except Exception as e:
            raise TrackError(e)

    def _fetch_data(self, entity_name: str, filter: Optional[str] = None, single: bool = False, cast: bool = False) -> Optional[List[Dict[str, Any]]]:
        """
        Helper method to fetch data from the database and convert it into dictionaries.

        Args:
            entity_name (str): The name of the entity.
            filter (Optional[str], optional): SQL filter to apply (e.g. "name='Bob' and age>20"). Defaults to None.
            single (bool, optional): Whether to fetch a single entity. Defaults to False.
            cast (bool, optional): Whether to cast values to their original types. Defaults to False.

        Returns:
            Optional[List[Dict[str, Any]]]: List of entities as dictionaries, or a single entity if `single` is True (can be None)

        Raises:
            TrackError: If there is an error while converting values or retrieving metadata from the database.
        """
        try:
            self._ensure_tables_exist(entity_name)
            keys = [row[0] for row in self.execute_sql(f"SELECT name FROM {entity_name}_meta")]
            types = [row[0] for row in self.execute_sql(f"SELECT type FROM {entity_name}_meta")]
            where_clause = f"WHERE {filter}" if filter else ''
            sql = f"SELECT {','.join(keys)} FROM {entity_name} {where_clause}"
            rows = self.execute_sql(sql)
            results = [self._db_values_to_entity(entity_name, row, keys, types, cast) for row in rows]            
            if single and len(results) == 0:
                return None
            return results[0] if single and results else results
        except Exception as e:
            raise TrackError(e)

    def get_entity(self, entity_name: str, id: str, cast: bool = False) -> Optional[Dict[str, Any]]:
        """
        Retrieve a single entity by its ID.

        Args:
            entity_name (str): The name of the entity.
            id (str): The ID of the entity.
            cast (bool, optional): Whether to cast values to their original types. Defaults to False.

        Returns:
            Optional[Dict[str, Any]]: The entity as a dictionary, or None if not found.
        
        Raises:
            TrackError: If there is an error while converting values or retrieving metadata from the database.
        """
        try:
            filter_clause = f"id = '{id}'"
            return self._fetch_data(entity_name, filter_clause, single=True, cast=cast)
        except Exception as e:
            raise TrackError(e)

    def get_entities(self, entity_name: str, filter: Optional[str] = None, cast: bool = False) -> List[Dict[str, Any]]:
        """
        Retrieve multiple entities with an optional filter.

        Args:
            entity_name (str): The name of the entity.
            filter (Optional[str], optional): SQL filter to apply (e.g. "name='Bob' and age>20"). Defaults to None.
            cast (bool, optional): Whether to cast values to their original types. Defaults to False.

        Returns:
            List[Dict[str, Any]]: List of entities as dictionaries.
        
        Raises:
            TrackError: If there is an error while converting values or retrieving metadata from the database.
        """
        try:
            return self._fetch_data(entity_name, filter, single=False, cast=cast)
        except Exception as e:
            raise TrackError(e)