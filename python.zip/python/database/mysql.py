import time, os
from . import mysql
from ..errors import TrackError
from .. import log as logger
from .. import utils
from . import config
from . import interface
from typing import List, Tuple, Any, Optional
import threading

thread_local_data = threading.local()

DEBUG_LEVEL = 11
connection_pool = None
background_connection_pool = None

class MySqlDataBase(interface.Database):
    """
    A class that manages the MySQL database connection, connection pooling, and SQL execution.

    This class handles the creation of a connection pool, acquiring connections,
    executing SQL queries, and managing transactions. 
    """
    @utils.profiled_function()
    def __init__(self, config: config.MySqlDataBaseConfig, env: str='prod', background: bool=False):
        """
        Initialize the MySQL database connection.

        Args:
            config (config.MySqlDataBaseConfig): Configuration object for MySQL database.
            env (str, optional): The environment for the connection. Defaults to 'prod'.
            background (bool optional): Wether the database will be used for background tasks (e.g. saving info about the requests) or more important things. Defaults to False.
        """
        try:
            super().__init__(config, env)
            self.__placeholder = '%s' 
            self.__connection = None
            self.__cursor = None      
            self.__background = background    
            logger.debug(f'Initializing db: {config}', DEBUG_LEVEL)
            
            # Configuration parameters            
            config_args = config['config'].get(str(env), {})           
            self.username = config_args.get('username')
            self.host = config_args.get('host')
            self.port = config_args.get('port')
            self.database = config_args.get('database')
            self.password = config.get('password', None)

            if not all([self.username, self.host, self.port, self.database]):
                raise TrackError(Exception(f'Missing MySQL config parameters for {self.alias()}'))

            # Get password from environment if not provided
            if self.password is None:
                self.password = os.environ.get(f'APP_MYSQL_PWD_{env.upper()}') or os.environ.get('APP_MYSQL_PWD')
                if not self.password:
                    raise TrackError(Exception(f'No password specified for MySQL {self.alias()}.'))

            # Initialize the connection pool if it doesn't exist
            self.create_pools()

            # Get a connection
            self.reset_connection()

        except Exception as e:
            raise TrackError(e)

    @utils.profiled_function()
    def create_pools(self):
        try:
            global connection_pool
            global background_connection_pool
            if connection_pool is None:               
                logger.info('Creating MySQL connection pool')
                connection_pool = mysql.connector.pooling.MySQLConnectionPool(
                    pool_name="connection_pool",
                    pool_size=10,
                    pool_reset_session=False,
                    connection_timeout=20,
                    host=self.host,
                    database=self.database,
                    user=self.username,
                    password=self.password
                )
            if background_connection_pool is None:               
                logger.info('Creating background MySQL connection pool')
                background_connection_pool = mysql.connector.pooling.MySQLConnectionPool(
                    pool_name="background_connection_pool",
                    pool_size=20,
                    pool_reset_session=False,
                    connection_timeout=60,
                    host=self.host,
                    database=self.database,
                    user=self.username,
                    password=self.password
                )
        except Exception as e:
            raise TrackError(e)

    def placeholder(self) -> str:
        return self.__placeholder

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close(exc_type)

    
    @utils.profiled_function()
    def reset_connection(self) -> None:
        """
        Reset the MySQL connection by closing the current connection and acquiring a new one from the connection pool.
        Uses thread-local storage to ensure each thread gets its own connection.
        """
        try:
            if not hasattr(thread_local_data, 'connection'):
                if self.__background:
                    thread_local_data.connection = background_connection_pool.get_connection()
                else:
                    thread_local_data.connection = connection_pool.get_connection()
                
                thread_local_data.cursor = thread_local_data.connection.cursor()

            if not thread_local_data.connection.is_connected():
                logger.debug('Attempting to reconnect...', DEBUG_LEVEL)
                thread_local_data.connection.reconnect(attempts=3, delay=5)
                
            if not thread_local_data.connection.is_connected():
                raise Exception('Failed to reconnect to MySQL.')
            
            thread_local_data.connection.autocommit = False
            self.__connection = thread_local_data.connection
            self.__cursor = thread_local_data.cursor
        except Exception as e:
            raise TrackError(e)

    @utils.profiled_function()
    def close(self, error: Optional[Exception] = None) -> None:
        """
        Close the MySQL connection and cursor safely, ensuring both are properly closed and set to None.
        Also ensure any pending sqls are committed (or rollback if error is not None)
        Logs any failure during closure.        
        """
        try:
            if hasattr(thread_local_data, 'cursor'):
                if error is None:
                    self.commit_transaction()                    
                else:
                    self.rollback_transaction()
                thread_local_data.cursor.close()
                del thread_local_data.cursor
            if hasattr(thread_local_data, 'connection'):
                thread_local_data.connection.close()
                del thread_local_data.connection  
        except Exception as e:
            logger.error(f'Error while closing connection of {self.alias()}: {e}')

    def clear_all(self):
        """
        Drop and recreate the entire database. Use with caution as it deletes all tables.
        """
        try:
            self.execute_sql(f'DROP DATABASE {self.database}')
            self.execute_sql(f'CREATE DATABASE {self.database}')
        except Exception as e:
            raise TrackError(e)

    def _execute_sql(self, sql: str, parameters: Tuple[Any, ...] = ()) -> List[Any]:
        """
        Internal method to execute a SQL query with optional parameters.
        Handles errors by raising TrackError if a failure occurs.

        Args:
            sql (str): The SQL query to execute.
            parameters (tuple): Parameters to safely inject into the query.

        Returns:
            list: Result of the query (typically rows from a SELECT query).

        Raises:
            TrackError: If there is a failure executing the query (rollback all pending sqls)
        """
        try:
            self.__cursor.execute(sql,parameters)
            return self.__cursor.fetchall()        
        except Exception as e:            
            raise TrackError(e)

    def execute_sql(self, sql: str = '', parameters: Tuple[Any, ...] = (), auto_commit: bool = False, max_retries: int = 3) -> List[Any]:
        """
        Execute a SQL query with optional parameters, retrying on failure.

        Args:
            sql (str): The SQL query to execute.
            parameters (Tuple[Any, ...], optional): Parameters for the SQL query. Defaults to ().
            auto_commit (bool, optional): Whether to auto commit the transaction. Defaults to False.
            max_retries (int, optional): Number of retries on failure. Defaults to 2.

        Returns:
            List[Any]: Query result.

        Raises:
            TrackError: If the query fails after all retries.
        """
        backoff = 1
        for _ in range(max_retries):
            try:
                res = self._execute_sql(sql, parameters)                
                if auto_commit:
                    self.commit_transaction()
                return res
            except Exception as e:
                error = e
                time.sleep(backoff)
                backoff *= 2  # Exponential backoff
        self.rollback_transaction()
        raise TrackError(Exception(f'Failed to execute SQL after {max_retries} retries: {error}'))

    def begin_transaction(self) -> None:
        """
        Begin a transaction by resetting the cursor.
        """
        try:
            self.__cursor.reset()
        except Exception as e:
            raise TrackError(e)

    def commit_transaction(self) -> None:
        """
        Commit the current transaction. Can be called multiple time without any harm.
        """
        try:
            self.__connection.commit()
        except Exception as e:
            raise TrackError(e)

    def rollback_transaction(self) -> None:
        """
        Roll back the current transaction. Can be called multiple time without any harm.
        """
        try:
            if self.__connection and self.__connection.is_connected():           
                self.__connection.rollback()
        except Exception as e:
            raise TrackError(e)
