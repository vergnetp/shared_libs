
import json
import psycopg2
from psycopg2.extras import RealDictCursor
from concurrent.futures import ThreadPoolExecutor
from ..errors import TrackError
from .interface import Database

class PostgresDatabase(Database):
    def __init__(self, config):
        self.config = config
        self.conn = None
        self.executor = ThreadPoolExecutor(max_workers=1)

    def connect(self):
        try:
            self.conn = psycopg2.connect(
                host=self.config.get("host"),
                user=self.config.get("user"),
                password=self.config.get("password"),
                dbname=self.config.get("database"),
                port=self.config.get("port", 5432),
                sslmode="require" if self.config.get("ssl", False) else "disable"
            )
        except Exception as e:
            raise TrackError(f"Failed to connect to PostgreSQL: {e}")

    def disconnect(self):
        if self.conn:
            self.conn.close()
            self.conn = None

    def save_object(self, table, obj):
        try:
            cursor = self.conn.cursor()
            keys = list(obj.keys())
            values = [json.dumps(v) if isinstance(v, (dict, list)) else v for v in obj.values()]

            cursor.execute(f'''
                CREATE TABLE IF NOT EXISTS "{table}" (
                    id SERIAL PRIMARY KEY
                )
            ''')

            for key in keys:
                cursor.execute(f'''
                    DO $$
                    BEGIN
                        IF NOT EXISTS (
                            SELECT 1
                            FROM information_schema.columns
                            WHERE table_name = %s AND column_name = %s
                        ) THEN
                            ALTER TABLE "{table}" ADD COLUMN "{key}" TEXT;
                        END IF;
                    END;
                    $$;
                ''', (table, key))

            columns = ", ".join(f'"{k}"' for k in keys)
            placeholders = ", ".join(["%s"] * len(values))
            cursor.execute(f'''
                INSERT INTO "{table}" ({columns})
                VALUES ({placeholders})
            ''', values)

            self.conn.commit()
        except Exception as e:
            self.conn.rollback()
            raise TrackError(f"PostgreSQL save_object error: {e}")

    def save_async(self, table, obj):
        self.executor.submit(self.save_object, table, obj)

    def delete(self, table, condition="TRUE"):
        try:
            cursor = self.conn.cursor()
            cursor.execute(f'DELETE FROM "{table}" WHERE {condition}')
            self.conn.commit()
        except Exception as e:
            self.conn.rollback()
            raise TrackError(f"PostgreSQL delete error: {e}")

    def get(self, table, condition="TRUE", limit=1):
        try:
            cursor = self.conn.cursor(cursor_factory=RealDictCursor)
            cursor.execute(f'SELECT * FROM "{table}" WHERE {condition} LIMIT {limit}')
            return cursor.fetchone() if limit == 1 else cursor.fetchall()
        except Exception as e:
            raise TrackError(f"PostgreSQL get error: {e}")

    def query(self, sql):
        try:
            cursor = self.conn.cursor(cursor_factory=RealDictCursor)
            cursor.execute(sql)
            return cursor.fetchall()
        except Exception as e:
            raise TrackError(f"PostgreSQL query error: {e}")
