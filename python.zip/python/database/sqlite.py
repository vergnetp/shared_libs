import time, os, json
import sqlite3
from ..errors import Error 
from ..log import debug, error
from .. import utils
from . import config
from . import interface
from ..errors import Error, TrackError

class SqliteDataBase(interface.Database):
    def __init__(self, config: config.SqliteDataBaseConfig, env='prod'): 
        try:       
            super().__init__(config, env)           
            debug('Initializing db: {0}'.format(config))
            self.__placeholder = '?'           
            try:
                config_path = config['config'][str(env)]['path']
            except:
                raise Exception('Error configuring a Sqlite database, {0} does not exist in {1}'.format(env, json.dumps(config)))
            self.__file_path = utils.path.build_relative_path(*config_path.split("|"))
            if not os.path.exists(os.path.dirname(self.__file_path)):
                raise Exception('Error accessing a Sqlite database, {0} does not exist'.format(os.path.dirname(self.__file_path)))
            open(self.__file_path, 'a').close() # ensure the file exists
            self.__connection = sqlite3.connect(self.__file_path)
            self.__connection.isolation_level = None
            self.__cursor = self.__connection.cursor()
        except Exception as e:
            raise TrackError(e)  

    def placeholder(self):
        return self.__placeholder
    
    def __del__(self):
        debug('destructing database {0}'.format(self.alias()))
        self.close()

    def __enter__(self):        
        return self

    def __exit__(self,a,b,c):
        debug('exiting database {0}'.format(self.alias()))
        self.close()
        pass

    def close(self):
        try:
            if self.__connection is not None:
                debug('Cleaning db {0}'.format(self.alias()))                
                self.__cursor.close()
                self.__connection.close()
                self.__connection = None
                self.__cursor = None
        except:
            pass

    def clear_all(self):
        try:
            self.close()
            os.remove(self.__file_path)
        except Exception as e:
            raise TrackError(e)

    def _execute_sqls(self, sqls=[]):
        try:
            rows = []
            self.__cursor.execute("begin")
            sql = ''
            try:
                for sq in sqls:
                    sql = sq
                    rows = self.__cursor.execute(sql).fetchall()
                self.__cursor.execute("commit")
                return rows
            except Exception as e:            
                self.__cursor.execute("rollback")
                raise Exception("Error while executing [{0}]: {1}".format(sql, str(e)))
        except Exception as e:
            raise TrackError(e)

    def execute_sqls(self, sqls=[], max_retries=10):
        try:
            error = ''
            for _ in range(max_retries):
                try:
                    rows = self._execute_sqls(sqls)
                    return rows
                except Exception as e:
                    error = str(e)
                    time.sleep(1)            
            raise Error(error,'sqlite.execute_sqls failed after {0} tries. The db is "{1}" '.format(max_retries, self.__database))
        except Exception as e:
            raise TrackError(e)
    
    def _execute_sql(self, sql='', parameters=()):
        try:
            res = self.__cursor.execute(sql, tuple(parameters))
            rows = res.fetchall()  
            return rows
        except Exception as e:
            raise TrackError(e)

    def execute_sql(self, sql='', parameters=(), max_retries=2):
        try:     
            error = None
            for _ in range(max_retries):
                try:
                    rows = self._execute_sql(sql, parameters)
                    return rows
                except Exception as e:
                    error = e
            raise Error(error, 'sqlite.execute_sql failed after {0} tries. The db is "{1}" and the sql: {2}, and the paramaters: {3}'.format(max_retries, self.alias(), sql, str(parameters)))
        except Exception as e:
            raise TrackError(e)
    
    def begin_transaction(self):
        try:
            self.__cursor.execute("begin")
        except Exception as e:
            raise TrackError(e)

    def commit_transaction(self):
        try:
            self.__cursor.execute("commit")
        except Exception as e:
            raise TrackError(e)

    def rollback_transaction(self):
        try:
            self.__cursor.execute("rollback")
        except Exception as e:
            raise TrackError(e)
