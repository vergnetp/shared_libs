import time
from .. import mysql
import pytest
import pymysql

@pytest.fixture(scope="session")
def wait_for_mysql():
    for _ in range(10):
        try:
            conn = pymysql.connect(
                host="localhost",
                port=3307,
                user="testuser",
                password="testpass",
                database="testdb"
            )
            conn.close()
            return
        except Exception:
            time.sleep(2)
    raise RuntimeError("MySQL not ready")

@pytest.fixture
def mysql_db(wait_for_mysql):
    config = {
        "host": "localhost",
        "port": 3307,
        "user": "testuser",
        "password": "testpass",
        "database": "testdb"
    }
    db = mysql.MySqlDataBase(config)
    db.connect()
    yield db
    db.disconnect()

def test_mysql_save_and_get(mysql_db):
    obj = {"id": "abc", "data": {"score": 42}}
    mysql_db.save_object("test_table", obj)
    result = mysql_db.get("test_table", 'id = "abc"')
    assert result["id"] == "abc"
