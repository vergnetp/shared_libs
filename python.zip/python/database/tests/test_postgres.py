
import time
from .. import postgres
import pytest
import psycopg2
from .. import postgres

@pytest.fixture(scope="session")
def wait_for_postgres():
    for _ in range(10):
        try:
            conn = psycopg2.connect(
                host="localhost",
                port=5433,
                user="testuser",
                password="testpass",
                dbname="testdb"
            )
            conn.close()
            return
        except Exception:
            time.sleep(2)
    raise RuntimeError("PostgreSQL not ready")

@pytest.fixture
def postgres_db(wait_for_postgres):
    config = {
        "host": "localhost",
        "port": 5433,
        "user": "testuser",
        "password": "testpass",
        "database": "testdb"
    }
    db = postgres.PostgresDatabase(config)
    db.connect()
    yield db
    db.disconnect()

def test_postgres_save_and_get(postgres_db):
    obj = {"id": "xyz", "score": {"a": 1}}
    postgres_db.save_object("test_pg_table", obj)
    result = postgres_db.get("test_pg_table", "id = 'xyz'")
    assert result["id"] == "xyz"
