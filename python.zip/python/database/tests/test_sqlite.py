
from ... import database
import pytest
import json

def get_config(db_path):
    return {"databases":[{"alias":"default","type":"sqlite","config":{"prod":{"path":str(db_path)}}}]}

def test_sqlite_save_and_get(tmp_path):
    db_path = tmp_path / "test.db"
    config = get_config(db_path)

    db = database.SqliteDataBase(config)
    db.connect()

    obj = {"id": "123", "name": "Alice", "data": {"score": 10}}
    db.save_object("users", obj)

    result = db.get("users", 'id = "123"')
    assert result is not None
    assert result["id"] == "123"
    assert json.loads(result["data"])["score"] == 10

    db.disconnect()

def test_sqlite_query(tmp_path):
    db_path = tmp_path / "query.db"    
    config = get_config(db_path)

    db = database.SqliteDataBase(config)
    db.connect()
    db.save_object("events", {"id": "evt1", "status": "ok"})

    results = db.query("SELECT * FROM events")
    assert isinstance(results, list)
    assert results[0]["id"] == "evt1"

    db.disconnect()

def test_sqlite_delete(tmp_path):
    db_path = tmp_path / "delete.db"
    config = get_config(db_path)

    db = database.SqliteDataBase(config)
    db.connect()

    db.save_object("logs", {"id": "log1", "msg": "keep"})
    db.delete("logs", 'id = "log1"')

    result = db.get("logs", 'id = "log1"')
    assert result is None

    db.disconnect()

def test_sqlite_async_write(tmp_path):
    db_path = tmp_path / "async.db"
    config = get_config(db_path)

    db = database.SqliteDataBase(config)
    db.connect()

    db.save_async("logs", {"id": "a1", "value": 99})
    db.executor.shutdown(wait=True)  # flush async work

    result = db.get("logs", 'id = "a1"')
    assert result["value"] == "99"  # value stored as string

    db.disconnect()
