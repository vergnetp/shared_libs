"""
logging package: info(msg)
"""
from .logging import *